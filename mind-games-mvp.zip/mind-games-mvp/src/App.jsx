import React, { useState, useEffect } from 'react';
import Hub from './components/Hub';
import PatternRecall from './games/PatternRecall';
import TaskSwitcher from './games/TaskSwitcher';
import ClarityCoach from './games/ClarityCoach';
import { getData, updateRating, updateStreak, addToHistory } from './utils/storage';

export default function App() {
  const [currentView, setCurrentView] = useState('hub');
  const [currentGame, setCurrentGame] = useState(null);
  const [gameData, setGameData] = useState(null);

  useEffect(() => {
    setGameData(getData());
  }, []);

  const handleSelectGame = (gameId) => {
    setCurrentGame(gameId);
    setCurrentView('game');
  };

  const handleBackToHub = () => {
    setCurrentView('hub');
    setCurrentGame(null);
    // Refresh data
    setGameData(getData());
  };

  const handleGameComplete = (result) => {
    // Update rating
    updateRating(result.gameId, result.rating);
    
    // Update streak
    updateStreak(true);
    
    // Add to history
    addToHistory({
      gameId: result.gameId,
      rating: result.rating,
      roundsWon: result.roundsWon,
      roundsPlayed: result.roundsPlayed,
    });
    
    // Refresh data
    setGameData(getData());
  };

  const getInitialRating = (gameId) => {
    return gameData?.ratings?.[gameId] || 1000;
  };

  if (currentView === 'hub') {
    return <Hub onSelectGame={handleSelectGame} />;
  }

  if (currentView === 'game') {
    const props = {
      onBack: handleBackToHub,
      initialRating: getInitialRating(currentGame),
      onComplete: handleGameComplete,
    };

    switch (currentGame) {
      case 'pattern':
        return <PatternRecall {...props} />;
      case 'switcher':
        return <TaskSwitcher {...props} />;
      case 'clarity':
        return <ClarityCoach {...props} />;
      default:
        return <Hub onSelectGame={handleSelectGame} />;
    }
  }

  return <Hub onSelectGame={handleSelectGame} />;
}
