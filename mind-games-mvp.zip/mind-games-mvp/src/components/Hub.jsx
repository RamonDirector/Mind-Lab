import React, { useState, useEffect } from 'react';
import { PatternIcon, SwitcherIcon, ClarityIcon, FlameIcon, ChevronIcon } from './Icons';
import { getData, getCombinedScore } from '../utils/storage';
import { elotoCognitiveScore, getPerformanceTier } from '../utils/elo';

const GAMES = [
  {
    id: 'pattern',
    name: 'Pattern Recall',
    domain: 'Working Memory',
    description: 'Observe luminous sequences and replicate them with precision',
    color: '#a78bfa',
    colorDark: '#7c3aed',
    gradient: 'linear-gradient(135deg, #a78bfa 0%, #7c3aed 100%)',
    shadowColor: 'rgba(167, 139, 250, 0.4)',
    rounds: 5,
    duration: 4,
    Icon: PatternIcon,
  },
  {
    id: 'switcher',
    name: 'Task Switcher',
    domain: 'Cognitive Flexibility',
    description: 'Adapt fluidly as rules shift mid-challenge',
    color: '#fbbf24',
    colorDark: '#d97706',
    gradient: 'linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%)',
    shadowColor: 'rgba(251, 191, 36, 0.4)',
    rounds: 5,
    duration: 5,
    Icon: SwitcherIcon,
  },
  {
    id: 'clarity',
    name: 'Clarity Coach',
    domain: 'Verbal Fluency',
    description: 'Articulate thoughts with precision and flow',
    color: '#34d399',
    colorDark: '#059669',
    gradient: 'linear-gradient(135deg, #34d399 0%, #10b981 100%)',
    shadowColor: 'rgba(52, 211, 153, 0.4)',
    rounds: 3,
    duration: 6,
    Icon: ClarityIcon,
  },
];

export default function Hub({ onSelectGame }) {
  const [data, setData] = useState(null);
  const [hoveredGame, setHoveredGame] = useState(null);

  useEffect(() => {
    setData(getData());
  }, []);

  const combinedScore = data ? getCombinedScore() : 0;
  const tier = getPerformanceTier(combinedScore);

  const styles = {
    container: {
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%)',
      padding: '24px',
      position: 'relative',
      overflow: 'hidden',
    },
    ambientOrb: {
      position: 'absolute',
      borderRadius: '50%',
      filter: 'blur(80px)',
      opacity: 0.15,
      pointerEvents: 'none',
    },
    orb1: {
      width: '400px',
      height: '400px',
      background: '#8b5cf6',
      top: '-100px',
      right: '-100px',
    },
    orb2: {
      width: '300px',
      height: '300px',
      background: '#10b981',
      bottom: '100px',
      left: '-100px',
    },
    orb3: {
      width: '250px',
      height: '250px',
      background: '#f59e0b',
      bottom: '-50px',
      right: '20%',
    },
    content: {
      position: 'relative',
      zIndex: 1,
      maxWidth: '480px',
      margin: '0 auto',
    },
    header: {
      textAlign: 'center',
      marginBottom: '32px',
      animation: 'fadeUp 0.6s ease-out',
    },
    logo: {
      width: '80px',
      height: '80px',
      margin: '0 auto 16px',
      background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.2) 0%, rgba(139, 92, 246, 0.1) 100%)',
      borderRadius: '24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: '1px solid rgba(139, 92, 246, 0.3)',
      boxShadow: '0 0 40px rgba(139, 92, 246, 0.2)',
    },
    logoInner: {
      width: '48px',
      height: '48px',
      background: 'linear-gradient(135deg, #a78bfa 0%, #7c3aed 100%)',
      borderRadius: '14px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    title: {
      fontSize: '2rem',
      fontWeight: '700',
      color: '#fff',
      marginBottom: '8px',
      letterSpacing: '-0.02em',
    },
    subtitle: {
      color: 'rgba(255,255,255,0.5)',
      fontSize: '1rem',
    },
    scoreCard: {
      background: 'rgba(255,255,255,0.03)',
      borderRadius: '20px',
      padding: '24px',
      marginBottom: '32px',
      border: '1px solid rgba(255,255,255,0.06)',
      backdropFilter: 'blur(20px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      animation: 'fadeUp 0.6s ease-out 0.1s both',
    },
    scoreMain: {
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
    },
    scoreCircle: {
      width: '64px',
      height: '64px',
      borderRadius: '50%',
      background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.2) 0%, rgba(139, 92, 246, 0.1) 100%)',
      border: '2px solid rgba(139, 92, 246, 0.4)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 0 20px rgba(139, 92, 246, 0.2)',
    },
    scoreValue: {
      fontSize: '1.5rem',
      fontWeight: '700',
      color: '#a78bfa',
    },
    scoreLabel: {
      color: 'rgba(255,255,255,0.5)',
      fontSize: '0.85rem',
      marginBottom: '4px',
    },
    scoreTier: {
      fontSize: '1.1rem',
      fontWeight: '600',
      color: '#fff',
    },
    streakBadge: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      background: 'rgba(251, 191, 36, 0.15)',
      padding: '8px 16px',
      borderRadius: '12px',
      border: '1px solid rgba(251, 191, 36, 0.3)',
    },
    streakValue: {
      color: '#fbbf24',
      fontWeight: '600',
    },
    sectionTitle: {
      color: 'rgba(255,255,255,0.4)',
      fontSize: '0.8rem',
      fontWeight: '600',
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      marginBottom: '16px',
      animation: 'fadeUp 0.6s ease-out 0.2s both',
    },
    gamesGrid: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px',
    },
    gameCard: {
      background: 'rgba(255,255,255,0.03)',
      borderRadius: '20px',
      padding: '24px',
      border: '1px solid rgba(255,255,255,0.06)',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      position: 'relative',
      overflow: 'hidden',
    },
    gameCardHover: {
      transform: 'translateY(-2px)',
      border: '1px solid rgba(255,255,255,0.12)',
    },
    gameHeader: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      marginBottom: '12px',
    },
    gameIcon: {
      width: '48px',
      height: '48px',
      borderRadius: '14px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    gameInfo: {
      flex: 1,
      marginLeft: '16px',
    },
    gameName: {
      fontSize: '1.1rem',
      fontWeight: '600',
      color: '#fff',
      marginBottom: '4px',
    },
    gameDomain: {
      fontSize: '0.8rem',
      fontWeight: '500',
    },
    gameDescription: {
      color: 'rgba(255,255,255,0.5)',
      fontSize: '0.9rem',
      lineHeight: '1.5',
      marginBottom: '16px',
    },
    gameFooter: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    gameMeta: {
      display: 'flex',
      gap: '16px',
    },
    gameMetaItem: {
      color: 'rgba(255,255,255,0.4)',
      fontSize: '0.8rem',
    },
    playButton: {
      display: 'flex',
      alignItems: 'center',
      gap: '4px',
      color: '#fff',
      fontSize: '0.9rem',
      fontWeight: '500',
    },
    gameGlow: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: '100%',
      opacity: 0,
      transition: 'opacity 0.3s ease',
      pointerEvents: 'none',
    },
    footer: {
      textAlign: 'center',
      marginTop: '32px',
      color: 'rgba(255,255,255,0.3)',
      fontSize: '0.8rem',
      animation: 'fadeUp 0.6s ease-out 0.5s both',
    },
  };

  return (
    <div style={styles.container}>
      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
      
      {/* Ambient orbs */}
      <div style={{ ...styles.ambientOrb, ...styles.orb1 }} />
      <div style={{ ...styles.ambientOrb, ...styles.orb2 }} />
      <div style={{ ...styles.ambientOrb, ...styles.orb3 }} />
      
      <div style={styles.content}>
        {/* Header */}
        <div style={styles.header}>
          <div style={styles.logo}>
            <div style={styles.logoInner}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M12 3L20 7.5V16.5L12 21L4 16.5V7.5L12 3Z" stroke="white" strokeWidth="2" strokeLinejoin="round"/>
                <circle cx="12" cy="12" r="3" fill="white"/>
              </svg>
            </div>
          </div>
          <h1 style={styles.title}>Mind Games</h1>
          <p style={styles.subtitle}>Train your cognitive edge</p>
        </div>
        
        {/* Score Card */}
        <div style={styles.scoreCard}>
          <div style={styles.scoreMain}>
            <div style={styles.scoreCircle}>
              <span style={styles.scoreValue}>{combinedScore}</span>
            </div>
            <div>
              <div style={styles.scoreLabel}>Cognitive Score</div>
              <div style={styles.scoreTier}>{tier}</div>
            </div>
          </div>
          {data?.streak?.current > 0 && (
            <div style={styles.streakBadge}>
              <FlameIcon size={18} />
              <span style={styles.streakValue}>{data.streak.current}</span>
            </div>
          )}
        </div>
        
        {/* Games Section */}
        <div style={styles.sectionTitle}>Training Modules</div>
        
        <div style={styles.gamesGrid}>
          {GAMES.map((game, index) => {
            const gameRating = data?.ratings?.[game.id] || 1000;
            const gameScore = elotoCognitiveScore(gameRating);
            const isHovered = hoveredGame === game.id;
            const Icon = game.Icon;
            
            return (
              <div
                key={game.id}
                style={{
                  ...styles.gameCard,
                  ...(isHovered ? styles.gameCardHover : {}),
                  boxShadow: isHovered ? `0 8px 32px ${game.shadowColor}` : 'none',
                  animation: `fadeUp 0.6s ease-out ${0.3 + index * 0.1}s both`,
                }}
                onMouseEnter={() => setHoveredGame(game.id)}
                onMouseLeave={() => setHoveredGame(null)}
                onClick={() => onSelectGame(game.id)}
              >
                <div 
                  style={{
                    ...styles.gameGlow,
                    background: `linear-gradient(135deg, ${game.shadowColor} 0%, transparent 60%)`,
                    opacity: isHovered ? 0.3 : 0,
                  }}
                />
                
                <div style={styles.gameHeader}>
                  <div style={{ ...styles.gameIcon, background: game.gradient }}>
                    <Icon size={24} color="#fff" />
                  </div>
                  <div style={styles.gameInfo}>
                    <div style={styles.gameName}>{game.name}</div>
                    <div style={{ ...styles.gameDomain, color: game.color }}>{game.domain}</div>
                  </div>
                  <div style={{ 
                    background: 'rgba(255,255,255,0.1)', 
                    padding: '4px 12px', 
                    borderRadius: '8px',
                    fontSize: '0.85rem',
                    color: game.color,
                    fontWeight: '600',
                  }}>
                    {gameScore}
                  </div>
                </div>
                
                <div style={styles.gameDescription}>{game.description}</div>
                
                <div style={styles.gameFooter}>
                  <div style={styles.gameMeta}>
                    <span style={styles.gameMetaItem}>{game.rounds} rounds</span>
                    <span style={styles.gameMetaItem}>~{game.duration} min</span>
                  </div>
                  <div style={{ ...styles.playButton, color: game.color }}>
                    Play <ChevronIcon size={16} color={game.color} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        <div style={styles.footer}>
          Built for cognitive enhancement
        </div>
      </div>
    </div>
  );
}
