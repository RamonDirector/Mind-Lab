import React from 'react';

export const PatternIcon = ({ size = 32, color = '#fff' }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
    <circle cx="8" cy="8" r="3" fill={color} opacity="0.9"/>
    <circle cx="16" cy="8" r="3" fill={color} opacity="0.5"/>
    <circle cx="24" cy="8" r="3" fill={color} opacity="0.9"/>
    <circle cx="8" cy="16" r="3" fill={color} opacity="0.5"/>
    <circle cx="16" cy="16" r="3" fill={color} opacity="0.9"/>
    <circle cx="24" cy="16" r="3" fill={color} opacity="0.5"/>
    <circle cx="8" cy="24" r="3" fill={color} opacity="0.9"/>
    <circle cx="16" cy="24" r="3" fill={color} opacity="0.5"/>
    <circle cx="24" cy="24" r="3" fill={color} opacity="0.9"/>
  </svg>
);

export const SwitcherIcon = ({ size = 32, color = '#fff' }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
    <path 
      d="M8 10 L24 10 M20 6 L24 10 L20 14" 
      stroke={color} 
      strokeWidth="2.5" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      opacity="0.9"
    />
    <path 
      d="M24 22 L8 22 M12 18 L8 22 L12 26" 
      stroke={color} 
      strokeWidth="2.5" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      opacity="0.6"
    />
  </svg>
);

export const ClarityIcon = ({ size = 32, color = '#fff' }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
    <path 
      d="M16 4 L16 8 M16 24 L16 28 M4 16 L8 16 M24 16 L28 16" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round"
      opacity="0.5"
    />
    <circle cx="16" cy="16" r="6" fill="none" stroke={color} strokeWidth="2.5" opacity="0.9"/>
    <circle cx="16" cy="16" r="2" fill={color} opacity="0.9"/>
  </svg>
);

export const DiamondIcon = ({ size = 20, color = '#fff' }) => (
  <svg width={size} height={size} viewBox="0 0 20 20" fill="none">
    <path 
      d="M10 2 L18 10 L10 18 L2 10 Z" 
      fill={color} 
      opacity="0.9"
    />
  </svg>
);

export const FlameIcon = ({ size = 20, color = '#f59e0b' }) => (
  <svg width={size} height={size} viewBox="0 0 20 20" fill="none">
    <path 
      d="M10 2 C10 2 6 6 6 10 C6 13 8 15 10 15 C8 13 9 11 10 10 C11 11 12 13 10 15 C12 15 14 13 14 10 C14 6 10 2 10 2 Z" 
      fill={color}
    />
  </svg>
);

export const ChevronIcon = ({ size = 16, color = '#fff', direction = 'right' }) => {
  const rotation = {
    right: 0,
    down: 90,
    left: 180,
    up: 270,
  };
  
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 16 16" 
      fill="none"
      style={{ transform: `rotate(${rotation[direction]}deg)` }}
    >
      <path 
        d="M6 4 L10 8 L6 12" 
        stroke={color} 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      />
    </svg>
  );
};

export const BackIcon = ({ size = 24, color = '#fff' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <path 
      d="M15 18 L9 12 L15 6" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    />
  </svg>
);

export const getGameIcon = (gameId, props = {}) => {
  const icons = {
    pattern: PatternIcon,
    switcher: SwitcherIcon,
    clarity: ClarityIcon,
  };
  
  const Icon = icons[gameId];
  return Icon ? <Icon {...props} /> : null;
};
