import React, { useState, useEffect, useRef } from 'react';
import { BackIcon } from '../components/Icons';
import { 
  INITIAL_ELO, 
  calculateExpectedScore, 
  updateElo, 
  getDifficultyRating,
  elotoCognitiveScore 
} from '../utils/elo';

const PROMPTS = [
  "Describe your ideal morning routine",
  "Explain why you enjoy your favorite hobby",
  "Tell a story about a memorable trip",
  "Describe your dream home",
  "Explain how to make your favorite meal",
  "Tell me about someone who inspired you",
  "Describe what success means to you",
  "Explain a skill you'd like to learn",
  "Tell a story about overcoming a challenge",
  "Describe your perfect weekend",
];

const FILLER_WORDS = ['um', 'uh', 'like', 'you know', 'basically', 'actually', 'literally', 'so', 'well'];
const ROUNDS_PER_SESSION = 3;
const SPEAKING_TIME = 30; // seconds

export default function ClarityCoach({ onBack, initialRating = INITIAL_ELO, onComplete }) {
  const [view, setView] = useState('instructions');
  const [userRating, setUserRating] = useState(initialRating);
  const [gameState, setGameState] = useState('idle');
  const [currentPrompt, setCurrentPrompt] = useState('');
  const [timeLeft, setTimeLeft] = useState(SPEAKING_TIME);
  const [transcript, setTranscript] = useState('');
  const [fillerCount, setFillerCount] = useState(0);
  const [roundsPlayed, setRoundsPlayed] = useState(0);
  const [roundsWon, setRoundsWon] = useState(0);
  const [feedback, setFeedback] = useState(null);
  const [isSupported, setIsSupported] = useState(true);
  
  const recognitionRef = useRef(null);
  const timerRef = useRef(null);
  const cognitiveScore = elotoCognitiveScore(userRating);

  useEffect(() => {
    // Check for Web Speech API support
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      setIsSupported(false);
    }
    
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, []);

  const countFillers = (text) => {
    const lowerText = text.toLowerCase();
    let count = 0;
    FILLER_WORDS.forEach(filler => {
      const regex = new RegExp(`\\b${filler}\\b`, 'gi');
      const matches = lowerText.match(regex);
      if (matches) count += matches.length;
    });
    return count;
  };

  const startGame = () => {
    setRoundsPlayed(0);
    setRoundsWon(0);
    setView('game');
    setTimeout(() => startRound(), 500);
  };

  const startRound = () => {
    const prompt = PROMPTS[Math.floor(Math.random() * PROMPTS.length)];
    setCurrentPrompt(prompt);
    setTranscript('');
    setFillerCount(0);
    setTimeLeft(SPEAKING_TIME);
    setGameState('ready');
    setFeedback(null);
  };

  const beginSpeaking = () => {
    setGameState('speaking');
    
    // Start timer
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          stopSpeaking();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    // Start speech recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognitionRef.current = new SpeechRecognition();
    recognitionRef.current.continuous = true;
    recognitionRef.current.interimResults = true;
    
    recognitionRef.current.onresult = (event) => {
      let fullTranscript = '';
      for (let i = 0; i < event.results.length; i++) {
        fullTranscript += event.results[i][0].transcript;
      }
      setTranscript(fullTranscript);
      setFillerCount(countFillers(fullTranscript));
    };
    
    recognitionRef.current.onerror = (event) => {
      console.log('Speech recognition error:', event.error);
    };
    
    recognitionRef.current.start();
  };

  const stopSpeaking = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }
    
    handleRoundEnd();
  };

  const handleRoundEnd = () => {
    setGameState('feedback');
    
    // Calculate score based on filler words
    const wordsSpoken = transcript.split(/\s+/).filter(w => w.length > 0).length;
    const fillerRate = wordsSpoken > 0 ? fillerCount / wordsSpoken : 1;
    const won = fillerRate < 0.05 && wordsSpoken >= 20; // Less than 5% fillers and at least 20 words
    
    const level = Math.max(1, Math.floor((userRating - 800) / 100));
    const difficultyRating = getDifficultyRating(level);
    const expected = calculateExpectedScore(userRating, difficultyRating);
    const newRating = updateElo(userRating, expected, won ? 1 : 0);
    
    setUserRating(newRating);
    setRoundsPlayed(p => p + 1);
    if (won) setRoundsWon(w => w + 1);
    
    setFeedback({
      won,
      ratingChange: newRating - userRating,
      wordsSpoken,
      fillerCount,
      fillerRate: Math.round(fillerRate * 100),
    });
  };

  const nextRound = () => {
    if (roundsPlayed >= ROUNDS_PER_SESSION) {
      setView('summary');
      if (onComplete) {
        onComplete({ 
          gameId: 'clarity',
          rating: userRating, 
          roundsWon, 
          roundsPlayed: ROUNDS_PER_SESSION 
        });
      }
    } else {
      startRound();
    }
  };

  const styles = {
    container: {
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '20px',
      position: 'relative',
    },
    header: {
      width: '100%',
      maxWidth: '400px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '24px',
    },
    backButton: {
      background: 'rgba(255,255,255,0.1)',
      border: 'none',
      borderRadius: '12px',
      padding: '12px',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    title: {
      fontSize: '1.5rem',
      fontWeight: '600',
      color: '#fff',
    },
    score: {
      background: 'rgba(52, 211, 153, 0.2)',
      borderRadius: '12px',
      padding: '8px 16px',
      fontSize: '0.9rem',
      color: '#34d399',
    },
    content: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      width: '100%',
      maxWidth: '400px',
    },
    promptCard: {
      background: 'rgba(255,255,255,0.05)',
      borderRadius: '24px',
      padding: '32px',
      textAlign: 'center',
      backdropFilter: 'blur(20px)',
      border: '1px solid rgba(255,255,255,0.1)',
      marginBottom: '32px',
      width: '100%',
    },
    prompt: {
      fontSize: '1.3rem',
      fontWeight: '500',
      color: '#fff',
      lineHeight: '1.5',
    },
    timer: {
      width: '120px',
      height: '120px',
      borderRadius: '50%',
      border: '4px solid rgba(52, 211, 153, 0.3)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: '24px',
      position: 'relative',
    },
    timerText: {
      fontSize: '2.5rem',
      fontWeight: '700',
      color: '#34d399',
    },
    timerRing: {
      position: 'absolute',
      top: '-4px',
      left: '-4px',
      width: '128px',
      height: '128px',
      borderRadius: '50%',
      border: '4px solid #34d399',
      borderTopColor: 'transparent',
      borderRightColor: 'transparent',
      transform: 'rotate(-45deg)',
      transition: 'transform 1s linear',
    },
    transcriptBox: {
      background: 'rgba(255,255,255,0.03)',
      borderRadius: '16px',
      padding: '16px',
      width: '100%',
      minHeight: '100px',
      maxHeight: '150px',
      overflow: 'auto',
      marginBottom: '24px',
    },
    transcriptText: {
      color: 'rgba(255,255,255,0.7)',
      lineHeight: '1.6',
      fontSize: '0.95rem',
    },
    fillerBadge: {
      display: 'inline-block',
      background: 'rgba(251, 191, 36, 0.2)',
      color: '#fbbf24',
      padding: '2px 8px',
      borderRadius: '4px',
      margin: '0 2px',
    },
    button: {
      background: 'linear-gradient(135deg, #34d399 0%, #10b981 100%)',
      border: 'none',
      borderRadius: '16px',
      padding: '16px 48px',
      color: '#000',
      fontSize: '1.1rem',
      fontWeight: '600',
      cursor: 'pointer',
      boxShadow: '0 4px 20px rgba(52, 211, 153, 0.4)',
    },
    stopButton: {
      background: 'linear-gradient(135deg, #f87171 0%, #ef4444 100%)',
      boxShadow: '0 4px 20px rgba(248, 113, 113, 0.4)',
    },
    feedbackCard: {
      background: 'rgba(255,255,255,0.05)',
      borderRadius: '24px',
      padding: '32px',
      textAlign: 'center',
      backdropFilter: 'blur(20px)',
      border: '1px solid rgba(255,255,255,0.1)',
    },
    instructionCard: {
      background: 'rgba(255,255,255,0.03)',
      borderRadius: '24px',
      padding: '32px',
      textAlign: 'center',
      backdropFilter: 'blur(20px)',
      border: '1px solid rgba(255,255,255,0.08)',
      maxWidth: '360px',
    },
    instructionTitle: {
      fontSize: '1.8rem',
      fontWeight: '700',
      marginBottom: '24px',
      color: '#fff',
    },
    instructionSection: {
      marginBottom: '20px',
      textAlign: 'left',
    },
    instructionLabel: {
      fontSize: '0.85rem',
      color: '#34d399',
      fontWeight: '600',
      marginBottom: '8px',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    instructionText: {
      color: 'rgba(255,255,255,0.7)',
      lineHeight: '1.6',
    },
    unsupported: {
      textAlign: 'center',
      padding: '32px',
    },
    roundProgress: {
      display: 'flex',
      gap: '8px',
      marginBottom: '24px',
    },
    roundDot: {
      width: '10px',
      height: '10px',
      borderRadius: '50%',
      background: 'rgba(255,255,255,0.2)',
    },
  };

  if (!isSupported) {
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <button style={styles.backButton} onClick={onBack}>
            <BackIcon color="#fff" />
          </button>
          <h1 style={styles.title}>Clarity Coach</h1>
          <div style={{ width: '48px' }} />
        </div>
        
        <div style={styles.content}>
          <div style={styles.unsupported}>
            <div style={{ fontSize: '3rem', marginBottom: '16px' }}>🎙️</div>
            <h2 style={{ color: '#fff', marginBottom: '16px' }}>Speech Recognition Unavailable</h2>
            <p style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '24px' }}>
              This game requires speech recognition, which isn't supported in your browser.
              Try Chrome, Edge, or Safari.
            </p>
            <button style={styles.button} onClick={onBack}>
              Back to Hub
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'instructions') {
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <button style={styles.backButton} onClick={onBack}>
            <BackIcon color="#fff" />
          </button>
          <h1 style={styles.title}>Clarity Coach</h1>
          <div style={{ width: '48px' }} />
        </div>
        
        <div style={styles.content}>
          <div style={styles.instructionCard}>
            <h2 style={styles.instructionTitle}>How to Play</h2>
            
            <div style={styles.instructionSection}>
              <div style={styles.instructionLabel}>🎯 Goal</div>
              <p style={styles.instructionText}>
                Speak for 30 seconds on a given topic. Avoid filler words like "um", "uh", "like", "you know".
              </p>
            </div>
            
            <div style={styles.instructionSection}>
              <div style={styles.instructionLabel}>🚫 Avoid</div>
              <p style={styles.instructionText}>
                Um, uh, like, you know, basically, actually, literally, so, well
              </p>
            </div>
            
            <div style={styles.instructionSection}>
              <div style={styles.instructionLabel}>💡 Tip</div>
              <p style={styles.instructionText}>
                Pause silently instead of using fillers. Slower, deliberate speech scores better.
              </p>
            </div>
            
            <button style={styles.button} onClick={startGame}>
              Begin Training
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'summary') {
    const winRate = Math.round((roundsWon / ROUNDS_PER_SESSION) * 100);
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <button style={styles.backButton} onClick={onBack}>
            <BackIcon color="#fff" />
          </button>
          <h1 style={styles.title}>Session Complete</h1>
          <div style={{ width: '48px' }} />
        </div>
        
        <div style={styles.content}>
          <div style={styles.feedbackCard}>
            <div style={{ fontSize: '3rem', marginBottom: '16px' }}>🎙️</div>
            <h2 style={{ fontSize: '2rem', fontWeight: '700', marginBottom: '8px', color: '#fff' }}>
              {winRate >= 67 ? 'Excellent!' : winRate >= 34 ? 'Good effort!' : 'Keep practicing!'}
            </h2>
            <p style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '24px' }}>
              You passed {roundsWon} of {ROUNDS_PER_SESSION} rounds
            </p>
            
            <div style={{ 
              display: 'flex', 
              justifyContent: 'center', 
              gap: '32px', 
              marginBottom: '24px' 
            }}>
              <div>
                <div style={{ fontSize: '2rem', fontWeight: '700', color: '#34d399' }}>{winRate}%</div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem' }}>Success</div>
              </div>
              <div>
                <div style={{ fontSize: '2rem', fontWeight: '700', color: '#a78bfa' }}>{cognitiveScore}</div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem' }}>Score</div>
              </div>
            </div>
            
            <button style={styles.button} onClick={onBack}>
              Back to Hub
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <button style={styles.backButton} onClick={onBack}>
          <BackIcon color="#fff" />
        </button>
        <h1 style={styles.title}>Clarity Coach</h1>
        <div style={styles.score}>{cognitiveScore}</div>
      </div>
      
      <div style={styles.content}>
        <div style={styles.roundProgress}>
          {Array.from({ length: ROUNDS_PER_SESSION }).map((_, i) => (
            <div 
              key={i} 
              style={{
                ...styles.roundDot,
                ...(i < roundsPlayed ? { background: i < roundsWon ? '#34d399' : '#f87171' } : {}),
                ...(i === roundsPlayed ? { background: '#34d399' } : {}),
              }}
            />
          ))}
        </div>

        {gameState === 'feedback' && feedback ? (
          <div style={styles.feedbackCard}>
            <h2 style={{
              fontSize: '2rem',
              fontWeight: '700',
              marginBottom: '16px',
              color: feedback.won ? '#34d399' : '#f87171',
            }}>
              {feedback.won ? 'Clear Speech!' : 'Too Many Fillers'}
            </h2>
            
            <div style={{ 
              display: 'grid', 
              gridTemplateColumns: '1fr 1fr', 
              gap: '16px',
              marginBottom: '24px',
            }}>
              <div style={{ 
                background: 'rgba(255,255,255,0.05)', 
                borderRadius: '12px', 
                padding: '16px' 
              }}>
                <div style={{ fontSize: '1.5rem', fontWeight: '700', color: '#fff' }}>
                  {feedback.wordsSpoken}
                </div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem' }}>
                  Words
                </div>
              </div>
              <div style={{ 
                background: 'rgba(255,255,255,0.05)', 
                borderRadius: '12px', 
                padding: '16px' 
              }}>
                <div style={{ 
                  fontSize: '1.5rem', 
                  fontWeight: '700', 
                  color: feedback.fillerCount > 2 ? '#f87171' : '#34d399' 
                }}>
                  {feedback.fillerCount}
                </div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem' }}>
                  Fillers
                </div>
              </div>
            </div>
            
            <div style={{
              fontSize: '1.5rem',
              fontWeight: '600',
              marginBottom: '24px',
              color: feedback.ratingChange > 0 ? '#34d399' : '#f87171',
            }}>
              {feedback.ratingChange > 0 ? '+' : ''}{feedback.ratingChange} rating
            </div>
            
            <button style={styles.button} onClick={nextRound}>
              {roundsPlayed >= ROUNDS_PER_SESSION ? 'See Results' : 'Next Prompt'}
            </button>
          </div>
        ) : (
          <>
            <div style={styles.promptCard}>
              <p style={styles.prompt}>{currentPrompt}</p>
            </div>
            
            {gameState === 'speaking' && (
              <>
                <div style={styles.timer}>
                  <div style={{
                    ...styles.timerRing,
                    transform: `rotate(${-45 + (360 * (1 - timeLeft / SPEAKING_TIME))}deg)`,
                  }} />
                  <span style={styles.timerText}>{timeLeft}</span>
                </div>
                
                <div style={styles.transcriptBox}>
                  <p style={styles.transcriptText}>
                    {transcript || 'Start speaking...'}
                  </p>
                </div>
                
                {fillerCount > 0 && (
                  <div style={{ 
                    color: '#fbbf24', 
                    marginBottom: '24px',
                    fontSize: '0.95rem',
                  }}>
                    Fillers detected: {fillerCount}
                  </div>
                )}
                
                <button 
                  style={{ ...styles.button, ...styles.stopButton }} 
                  onClick={stopSpeaking}
                >
                  Stop Early
                </button>
              </>
            )}
            
            {gameState === 'ready' && (
              <button style={styles.button} onClick={beginSpeaking}>
                Start Speaking
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}
