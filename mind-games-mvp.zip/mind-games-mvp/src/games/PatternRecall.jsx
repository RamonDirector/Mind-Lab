import React, { useState, useEffect, useCallback } from 'react';
import { BackIcon } from '../components/Icons';
import { 
  INITIAL_ELO, 
  calculateExpectedScore, 
  updateElo, 
  getDifficultyRating,
  elotoCognitiveScore,
  getStartingLevel 
} from '../utils/elo';

const ROUNDS_PER_SESSION = 5;

const successMessages = ['Perfect', 'Brilliant', 'Sharp', 'Flawless', 'Precise'];
const errorMessages = [
  { main: 'Almost', sub: 'Keep focusing' },
  { main: 'Close', sub: 'Trust your memory' },
  { main: 'Reset', sub: 'New pattern incoming' },
];

export default function PatternRecall({ onBack, initialRating = INITIAL_ELO, onComplete }) {
  const [view, setView] = useState('instructions');
  const [userRating, setUserRating] = useState(initialRating);
  const [gameState, setGameState] = useState('idle');
  const [sequence, setSequence] = useState([]);
  const [userSequence, setUserSequence] = useState([]);
  const [level, setLevel] = useState(1);
  const [activeCell, setActiveCell] = useState(null);
  const [showingIndex, setShowingIndex] = useState(-1);
  const [feedback, setFeedback] = useState(null);
  const [roundsPlayed, setRoundsPlayed] = useState(0);
  const [roundsWon, setRoundsWon] = useState(0);

  const cognitiveScore = elotoCognitiveScore(userRating);

  const generateSequence = useCallback((len) => {
    const seq = [];
    for (let i = 0; i < len; i++) {
      seq.push(Math.floor(Math.random() * 9));
    }
    return seq;
  }, []);

  const startGame = () => {
    const initialLevel = getStartingLevel(userRating);
    setLevel(initialLevel);
    setRoundsPlayed(0);
    setRoundsWon(0);
    setView('game');
    setTimeout(() => startRound(initialLevel), 500);
  };

  const startRound = (lvl) => {
    const newSeq = generateSequence(lvl + 2);
    setSequence(newSeq);
    setUserSequence([]);
    setGameState('showing');
    setFeedback(null);
    showSequence(newSeq);
  };

  const showSequence = (seq) => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < seq.length) {
        setShowingIndex(seq[i]);
        setTimeout(() => setShowingIndex(-1), 400);
        i++;
      } else {
        clearInterval(interval);
        setGameState('input');
      }
    }, 600);
  };

  const handleCellClick = (index) => {
    if (gameState !== 'input') return;

    setActiveCell(index);
    setTimeout(() => setActiveCell(null), 150);

    const newUserSeq = [...userSequence, index];
    setUserSequence(newUserSeq);

    const currentPos = newUserSeq.length - 1;
    if (newUserSeq[currentPos] !== sequence[currentPos]) {
      handleRoundEnd(false);
      return;
    }

    if (newUserSeq.length === sequence.length) {
      handleRoundEnd(true);
    }
  };

  const handleRoundEnd = (won) => {
    setGameState('feedback');
    
    const difficultyRating = getDifficultyRating(level);
    const expected = calculateExpectedScore(userRating, difficultyRating);
    const newRating = updateElo(userRating, expected, won ? 1 : 0);
    
    setUserRating(newRating);
    setRoundsPlayed(p => p + 1);
    if (won) setRoundsWon(w => w + 1);

    const msg = won 
      ? successMessages[Math.floor(Math.random() * successMessages.length)]
      : errorMessages[Math.floor(Math.random() * errorMessages.length)];
    
    setFeedback({ won, message: msg, ratingChange: newRating - userRating });

    if (won) {
      setLevel(l => l + 1);
    } else {
      setLevel(l => Math.max(1, l - 1));
    }
  };

  const nextRound = () => {
    if (roundsPlayed >= ROUNDS_PER_SESSION) {
      setView('summary');
      if (onComplete) {
        onComplete({ 
          gameId: 'pattern',
          rating: userRating, 
          roundsWon, 
          roundsPlayed: ROUNDS_PER_SESSION 
        });
      }
    } else {
      startRound(level);
    }
  };

  const styles = {
    container: {
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '20px',
      position: 'relative',
      overflow: 'hidden',
    },
    header: {
      width: '100%',
      maxWidth: '400px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '24px',
    },
    backButton: {
      background: 'rgba(255,255,255,0.1)',
      border: 'none',
      borderRadius: '12px',
      padding: '12px',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    title: {
      fontSize: '1.5rem',
      fontWeight: '600',
      color: '#fff',
    },
    score: {
      background: 'rgba(167, 139, 250, 0.2)',
      borderRadius: '12px',
      padding: '8px 16px',
      fontSize: '0.9rem',
      color: '#a78bfa',
    },
    content: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      width: '100%',
      maxWidth: '400px',
    },
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: '12px',
      marginBottom: '32px',
    },
    cell: {
      width: '90px',
      height: '90px',
      borderRadius: '16px',
      background: 'rgba(255,255,255,0.05)',
      border: '2px solid rgba(255,255,255,0.1)',
      cursor: 'pointer',
      transition: 'all 0.15s ease',
    },
    cellActive: {
      background: 'linear-gradient(135deg, #a78bfa 0%, #7c3aed 100%)',
      boxShadow: '0 0 30px rgba(167, 139, 250, 0.6)',
      border: '2px solid rgba(255,255,255,0.3)',
    },
    progress: {
      display: 'flex',
      gap: '8px',
      marginBottom: '24px',
    },
    progressDot: {
      width: '10px',
      height: '10px',
      borderRadius: '50%',
      background: 'rgba(255,255,255,0.2)',
    },
    progressDotActive: {
      background: '#a78bfa',
    },
    progressDotWon: {
      background: '#34d399',
    },
    progressDotLost: {
      background: '#f87171',
    },
    feedbackCard: {
      background: 'rgba(255,255,255,0.05)',
      borderRadius: '24px',
      padding: '32px',
      textAlign: 'center',
      backdropFilter: 'blur(20px)',
      border: '1px solid rgba(255,255,255,0.1)',
    },
    feedbackTitle: {
      fontSize: '2rem',
      fontWeight: '700',
      marginBottom: '8px',
    },
    feedbackSub: {
      color: 'rgba(255,255,255,0.6)',
      marginBottom: '24px',
    },
    ratingChange: {
      fontSize: '1.5rem',
      fontWeight: '600',
      marginBottom: '24px',
    },
    button: {
      background: 'linear-gradient(135deg, #a78bfa 0%, #7c3aed 100%)',
      border: 'none',
      borderRadius: '16px',
      padding: '16px 48px',
      color: '#fff',
      fontSize: '1.1rem',
      fontWeight: '600',
      cursor: 'pointer',
      boxShadow: '0 4px 20px rgba(139, 92, 246, 0.4)',
    },
    instructionCard: {
      background: 'rgba(255,255,255,0.03)',
      borderRadius: '24px',
      padding: '32px',
      textAlign: 'center',
      backdropFilter: 'blur(20px)',
      border: '1px solid rgba(255,255,255,0.08)',
      maxWidth: '360px',
    },
    instructionTitle: {
      fontSize: '1.8rem',
      fontWeight: '700',
      marginBottom: '24px',
      color: '#fff',
    },
    instructionSection: {
      marginBottom: '20px',
      textAlign: 'left',
    },
    instructionLabel: {
      fontSize: '0.85rem',
      color: '#a78bfa',
      fontWeight: '600',
      marginBottom: '8px',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    instructionText: {
      color: 'rgba(255,255,255,0.7)',
      lineHeight: '1.6',
    },
    stateText: {
      fontSize: '1.2rem',
      color: 'rgba(255,255,255,0.6)',
      marginBottom: '16px',
    },
    levelBadge: {
      background: 'rgba(167, 139, 250, 0.2)',
      borderRadius: '20px',
      padding: '8px 20px',
      color: '#a78bfa',
      fontSize: '0.9rem',
      fontWeight: '600',
      marginBottom: '32px',
    },
  };

  if (view === 'instructions') {
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <button style={styles.backButton} onClick={onBack}>
            <BackIcon color="#fff" />
          </button>
          <h1 style={styles.title}>Pattern Recall</h1>
          <div style={{ width: '48px' }} />
        </div>
        
        <div style={styles.content}>
          <div style={styles.instructionCard}>
            <h2 style={styles.instructionTitle}>How to Play</h2>
            
            <div style={styles.instructionSection}>
              <div style={styles.instructionLabel}>🎯 Goal</div>
              <p style={styles.instructionText}>
                Watch the tiles light up in sequence, then tap them back in the exact same order.
              </p>
            </div>
            
            <div style={styles.instructionSection}>
              <div style={styles.instructionLabel}>📈 Scoring</div>
              <p style={styles.instructionText}>
                Longer sequences = harder challenges. Beat harder patterns to earn more rating points.
              </p>
            </div>
            
            <div style={styles.instructionSection}>
              <div style={styles.instructionLabel}>💡 Tip</div>
              <p style={styles.instructionText}>
                Focus on the pattern's shape, not individual tiles. Your brain is better at shapes than lists.
              </p>
            </div>
            
            <button style={styles.button} onClick={startGame}>
              Begin Training
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'summary') {
    const accuracy = Math.round((roundsWon / ROUNDS_PER_SESSION) * 100);
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <button style={styles.backButton} onClick={onBack}>
            <BackIcon color="#fff" />
          </button>
          <h1 style={styles.title}>Session Complete</h1>
          <div style={{ width: '48px' }} />
        </div>
        
        <div style={styles.content}>
          <div style={styles.feedbackCard}>
            <div style={{ fontSize: '3rem', marginBottom: '16px' }}>🧠</div>
            <h2 style={styles.feedbackTitle}>{accuracy >= 80 ? 'Excellent!' : accuracy >= 60 ? 'Good work!' : 'Keep practicing!'}</h2>
            <p style={styles.feedbackSub}>You completed {roundsWon} of {ROUNDS_PER_SESSION} patterns</p>
            
            <div style={{ 
              display: 'flex', 
              justifyContent: 'center', 
              gap: '32px', 
              marginBottom: '24px' 
            }}>
              <div>
                <div style={{ fontSize: '2rem', fontWeight: '700', color: '#a78bfa' }}>{accuracy}%</div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem' }}>Accuracy</div>
              </div>
              <div>
                <div style={{ fontSize: '2rem', fontWeight: '700', color: '#34d399' }}>{cognitiveScore}</div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem' }}>Score</div>
              </div>
            </div>
            
            <button style={styles.button} onClick={onBack}>
              Back to Hub
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <button style={styles.backButton} onClick={onBack}>
          <BackIcon color="#fff" />
        </button>
        <h1 style={styles.title}>Pattern Recall</h1>
        <div style={styles.score}>{cognitiveScore}</div>
      </div>
      
      <div style={styles.content}>
        <div style={styles.progress}>
          {Array.from({ length: ROUNDS_PER_SESSION }).map((_, i) => (
            <div 
              key={i} 
              style={{
                ...styles.progressDot,
                ...(i < roundsPlayed ? (i < roundsWon ? styles.progressDotWon : styles.progressDotLost) : {}),
                ...(i === roundsPlayed ? styles.progressDotActive : {}),
              }}
            />
          ))}
        </div>
        
        <div style={styles.levelBadge}>
          Level {level} · {level + 2} tiles
        </div>
        
        {gameState === 'showing' && (
          <div style={styles.stateText}>Watch the pattern...</div>
        )}
        {gameState === 'input' && (
          <div style={styles.stateText}>Your turn! Tap the sequence</div>
        )}
        
        {gameState !== 'feedback' && (
          <div style={styles.grid}>
            {Array.from({ length: 9 }).map((_, i) => (
              <div
                key={i}
                style={{
                  ...styles.cell,
                  ...(showingIndex === i || activeCell === i ? styles.cellActive : {}),
                }}
                onClick={() => handleCellClick(i)}
              />
            ))}
          </div>
        )}
        
        {gameState === 'feedback' && feedback && (
          <div style={styles.feedbackCard}>
            <h2 style={{
              ...styles.feedbackTitle,
              color: feedback.won ? '#34d399' : '#f87171',
            }}>
              {typeof feedback.message === 'string' ? feedback.message : feedback.message.main}
            </h2>
            {typeof feedback.message === 'object' && (
              <p style={styles.feedbackSub}>{feedback.message.sub}</p>
            )}
            <div style={{
              ...styles.ratingChange,
              color: feedback.ratingChange > 0 ? '#34d399' : '#f87171',
            }}>
              {feedback.ratingChange > 0 ? '+' : ''}{feedback.ratingChange} rating
            </div>
            <button style={styles.button} onClick={nextRound}>
              {roundsPlayed >= ROUNDS_PER_SESSION ? 'See Results' : 'Next Pattern'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
