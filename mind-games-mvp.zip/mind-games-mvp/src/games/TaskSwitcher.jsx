import React, { useState, useEffect, useCallback, useRef } from 'react';
import { BackIcon } from '../components/Icons';
import { 
  INITIAL_ELO, 
  calculateExpectedScore, 
  updateElo, 
  getDifficultyRating,
  elotoCognitiveScore 
} from '../utils/elo';

const TRIALS_PER_ROUND = 8;
const SWITCH_EVERY = 4;
const ROUNDS_PER_SESSION = 5;

const COLORS = ['violet', 'amber'];
const SHAPES = ['circle', 'square'];

const colorMap = {
  violet: { bg: 'linear-gradient(135deg, #8b5cf6 0%, #a78bfa 100%)', shadow: 'rgba(139, 92, 246, 0.6)' },
  amber: { bg: 'linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%)', shadow: 'rgba(251, 191, 36, 0.6)' },
};

const successMessages = ['Sharp', 'Quick', 'Fluid', 'Agile', 'Adaptive'];
const errorMessages = [
  { main: 'Switched up', sub: 'Stay adaptable' },
  { main: 'Tricky one', sub: 'Keep your focus' },
  { main: 'Reset', sub: 'New trial, fresh start' },
];

export default function TaskSwitcher({ onBack, initialRating = INITIAL_ELO, onComplete }) {
  const [view, setView] = useState('instructions');
  const [userRating, setUserRating] = useState(initialRating);
  const [level, setLevel] = useState(1);
  const [gameState, setGameState] = useState('idle');
  const [currentRule, setCurrentRule] = useState('color');
  const [currentStimulus, setCurrentStimulus] = useState(null);
  const [trialCount, setTrialCount] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [roundsPlayed, setRoundsPlayed] = useState(0);
  const [roundsWon, setRoundsWon] = useState(0);
  const [feedback, setFeedback] = useState(null);
  const [showRuleSwitch, setShowRuleSwitch] = useState(false);
  
  const timeoutRef = useRef(null);
  const cognitiveScore = elotoCognitiveScore(userRating);

  const generateStimulus = () => {
    return {
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      shape: SHAPES[Math.floor(Math.random() * SHAPES.length)],
    };
  };

  const startGame = () => {
    setLevel(Math.max(1, Math.floor((userRating - 800) / 100)));
    setRoundsPlayed(0);
    setRoundsWon(0);
    setView('game');
    setTimeout(() => startRound(), 500);
  };

  const startRound = () => {
    setTrialCount(0);
    setCorrectCount(0);
    setCurrentRule('color');
    setFeedback(null);
    setGameState('playing');
    nextTrial(0, 'color');
  };

  const nextTrial = (trial, rule) => {
    // Check for rule switch
    if (trial > 0 && trial % SWITCH_EVERY === 0) {
      const newRule = rule === 'color' ? 'shape' : 'color';
      setCurrentRule(newRule);
      setShowRuleSwitch(true);
      
      timeoutRef.current = setTimeout(() => {
        setShowRuleSwitch(false);
        setCurrentStimulus(generateStimulus());
      }, 1200);
    } else {
      setCurrentStimulus(generateStimulus());
    }
  };

  const handleResponse = (response) => {
    if (gameState !== 'playing' || showRuleSwitch) return;
    
    const isCorrect = currentRule === 'color' 
      ? response === currentStimulus.color
      : response === currentStimulus.shape;
    
    const newTrialCount = trialCount + 1;
    const newCorrectCount = correctCount + (isCorrect ? 1 : 0);
    
    setTrialCount(newTrialCount);
    setCorrectCount(newCorrectCount);
    
    // Quick visual feedback
    setFeedback({ correct: isCorrect });
    setTimeout(() => setFeedback(null), 200);
    
    if (newTrialCount >= TRIALS_PER_ROUND) {
      handleRoundEnd(newCorrectCount);
    } else {
      nextTrial(newTrialCount, currentRule);
    }
  };

  const handleRoundEnd = (correct) => {
    setGameState('roundEnd');
    
    const accuracy = correct / TRIALS_PER_ROUND;
    const won = accuracy >= 0.75;
    
    const difficultyRating = getDifficultyRating(level);
    const expected = calculateExpectedScore(userRating, difficultyRating);
    const newRating = updateElo(userRating, expected, won ? 1 : 0);
    
    setUserRating(newRating);
    setRoundsPlayed(p => p + 1);
    if (won) setRoundsWon(w => w + 1);
    
    const msg = won 
      ? successMessages[Math.floor(Math.random() * successMessages.length)]
      : errorMessages[Math.floor(Math.random() * errorMessages.length)];
    
    setFeedback({ 
      won, 
      message: msg, 
      ratingChange: newRating - userRating,
      accuracy: Math.round(accuracy * 100),
      correct,
    });
    
    if (won) {
      setLevel(l => l + 1);
    } else {
      setLevel(l => Math.max(1, l - 1));
    }
  };

  const nextRound = () => {
    if (roundsPlayed >= ROUNDS_PER_SESSION) {
      setView('summary');
      if (onComplete) {
        onComplete({ 
          gameId: 'switcher',
          rating: userRating, 
          roundsWon, 
          roundsPlayed: ROUNDS_PER_SESSION 
        });
      }
    } else {
      startRound();
    }
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const styles = {
    container: {
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '20px',
      position: 'relative',
    },
    header: {
      width: '100%',
      maxWidth: '400px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '24px',
    },
    backButton: {
      background: 'rgba(255,255,255,0.1)',
      border: 'none',
      borderRadius: '12px',
      padding: '12px',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    title: {
      fontSize: '1.5rem',
      fontWeight: '600',
      color: '#fff',
    },
    score: {
      background: 'rgba(251, 191, 36, 0.2)',
      borderRadius: '12px',
      padding: '8px 16px',
      fontSize: '0.9rem',
      color: '#fbbf24',
    },
    content: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      width: '100%',
      maxWidth: '400px',
    },
    ruleBadge: {
      padding: '12px 24px',
      borderRadius: '20px',
      fontSize: '1rem',
      fontWeight: '600',
      marginBottom: '32px',
      background: 'rgba(255,255,255,0.1)',
      border: '2px solid',
    },
    stimulusContainer: {
      width: '160px',
      height: '160px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: '48px',
    },
    stimulus: {
      width: '120px',
      height: '120px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'all 0.2s ease',
    },
    responseButtons: {
      display: 'flex',
      gap: '16px',
      width: '100%',
      maxWidth: '320px',
    },
    responseButton: {
      flex: 1,
      padding: '20px',
      borderRadius: '16px',
      border: 'none',
      fontSize: '1rem',
      fontWeight: '600',
      cursor: 'pointer',
      transition: 'all 0.15s ease',
      color: '#fff',
    },
    progress: {
      display: 'flex',
      gap: '6px',
      marginBottom: '24px',
    },
    progressBar: {
      width: '28px',
      height: '6px',
      borderRadius: '3px',
      background: 'rgba(255,255,255,0.2)',
    },
    progressBarFilled: {
      background: '#fbbf24',
    },
    switchAlert: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      background: 'rgba(0,0,0,0.9)',
      borderRadius: '24px',
      padding: '32px 48px',
      textAlign: 'center',
      zIndex: 10,
      border: '2px solid rgba(251, 191, 36, 0.5)',
      boxShadow: '0 0 40px rgba(251, 191, 36, 0.3)',
    },
    feedbackCard: {
      background: 'rgba(255,255,255,0.05)',
      borderRadius: '24px',
      padding: '32px',
      textAlign: 'center',
      backdropFilter: 'blur(20px)',
      border: '1px solid rgba(255,255,255,0.1)',
    },
    button: {
      background: 'linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%)',
      border: 'none',
      borderRadius: '16px',
      padding: '16px 48px',
      color: '#000',
      fontSize: '1.1rem',
      fontWeight: '600',
      cursor: 'pointer',
      boxShadow: '0 4px 20px rgba(251, 191, 36, 0.4)',
    },
    instructionCard: {
      background: 'rgba(255,255,255,0.03)',
      borderRadius: '24px',
      padding: '32px',
      textAlign: 'center',
      backdropFilter: 'blur(20px)',
      border: '1px solid rgba(255,255,255,0.08)',
      maxWidth: '360px',
    },
    instructionTitle: {
      fontSize: '1.8rem',
      fontWeight: '700',
      marginBottom: '24px',
      color: '#fff',
    },
    instructionSection: {
      marginBottom: '20px',
      textAlign: 'left',
    },
    instructionLabel: {
      fontSize: '0.85rem',
      color: '#fbbf24',
      fontWeight: '600',
      marginBottom: '8px',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    instructionText: {
      color: 'rgba(255,255,255,0.7)',
      lineHeight: '1.6',
    },
    roundProgress: {
      display: 'flex',
      gap: '8px',
      marginBottom: '16px',
    },
    roundDot: {
      width: '10px',
      height: '10px',
      borderRadius: '50%',
      background: 'rgba(255,255,255,0.2)',
    },
  };

  if (view === 'instructions') {
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <button style={styles.backButton} onClick={onBack}>
            <BackIcon color="#fff" />
          </button>
          <h1 style={styles.title}>Task Switcher</h1>
          <div style={{ width: '48px' }} />
        </div>
        
        <div style={styles.content}>
          <div style={styles.instructionCard}>
            <h2 style={styles.instructionTitle}>How to Play</h2>
            
            <div style={styles.instructionSection}>
              <div style={styles.instructionLabel}>🎯 Goal</div>
              <p style={styles.instructionText}>
                Respond based on the current rule: sort by COLOR or by SHAPE. The rule switches mid-round!
              </p>
            </div>
            
            <div style={styles.instructionSection}>
              <div style={styles.instructionLabel}>🔄 The Switch</div>
              <p style={styles.instructionText}>
                Every 4 trials, the rule flips. Staying flexible is the challenge.
              </p>
            </div>
            
            <div style={styles.instructionSection}>
              <div style={styles.instructionLabel}>💡 Tip</div>
              <p style={styles.instructionText}>
                Read the rule badge before each response. Speed matters, but accuracy wins.
              </p>
            </div>
            
            <button style={styles.button} onClick={startGame}>
              Begin Training
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'summary') {
    const accuracy = Math.round((roundsWon / ROUNDS_PER_SESSION) * 100);
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <button style={styles.backButton} onClick={onBack}>
            <BackIcon color="#fff" />
          </button>
          <h1 style={styles.title}>Session Complete</h1>
          <div style={{ width: '48px' }} />
        </div>
        
        <div style={styles.content}>
          <div style={styles.feedbackCard}>
            <div style={{ fontSize: '3rem', marginBottom: '16px' }}>🔄</div>
            <h2 style={{ fontSize: '2rem', fontWeight: '700', marginBottom: '8px', color: '#fff' }}>
              {accuracy >= 80 ? 'Excellent!' : accuracy >= 60 ? 'Good work!' : 'Keep practicing!'}
            </h2>
            <p style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '24px' }}>
              You won {roundsWon} of {ROUNDS_PER_SESSION} rounds
            </p>
            
            <div style={{ 
              display: 'flex', 
              justifyContent: 'center', 
              gap: '32px', 
              marginBottom: '24px' 
            }}>
              <div>
                <div style={{ fontSize: '2rem', fontWeight: '700', color: '#fbbf24' }}>{accuracy}%</div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem' }}>Win Rate</div>
              </div>
              <div>
                <div style={{ fontSize: '2rem', fontWeight: '700', color: '#34d399' }}>{cognitiveScore}</div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem' }}>Score</div>
              </div>
            </div>
            
            <button style={styles.button} onClick={onBack}>
              Back to Hub
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <button style={styles.backButton} onClick={onBack}>
          <BackIcon color="#fff" />
        </button>
        <h1 style={styles.title}>Task Switcher</h1>
        <div style={styles.score}>{cognitiveScore}</div>
      </div>
      
      <div style={styles.content}>
        {showRuleSwitch && (
          <div style={styles.switchAlert}>
            <div style={{ fontSize: '2rem', marginBottom: '12px' }}>🔄</div>
            <div style={{ fontSize: '1.5rem', fontWeight: '700', color: '#fbbf24' }}>
              RULE SWITCH
            </div>
            <div style={{ color: 'rgba(255,255,255,0.7)', marginTop: '8px' }}>
              Now sort by {currentRule.toUpperCase()}
            </div>
          </div>
        )}
        
        {gameState === 'roundEnd' && feedback ? (
          <div style={styles.feedbackCard}>
            <h2 style={{
              fontSize: '2rem',
              fontWeight: '700',
              marginBottom: '8px',
              color: feedback.won ? '#34d399' : '#f87171',
            }}>
              {typeof feedback.message === 'string' ? feedback.message : feedback.message.main}
            </h2>
            {typeof feedback.message === 'object' && (
              <p style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '16px' }}>{feedback.message.sub}</p>
            )}
            <p style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '8px' }}>
              {feedback.correct}/{TRIALS_PER_ROUND} correct ({feedback.accuracy}%)
            </p>
            <div style={{
              fontSize: '1.5rem',
              fontWeight: '600',
              marginBottom: '24px',
              color: feedback.ratingChange > 0 ? '#34d399' : '#f87171',
            }}>
              {feedback.ratingChange > 0 ? '+' : ''}{feedback.ratingChange} rating
            </div>
            <button style={styles.button} onClick={nextRound}>
              {roundsPlayed >= ROUNDS_PER_SESSION ? 'See Results' : 'Next Round'}
            </button>
          </div>
        ) : (
          <>
            <div style={styles.roundProgress}>
              {Array.from({ length: ROUNDS_PER_SESSION }).map((_, i) => (
                <div 
                  key={i} 
                  style={{
                    ...styles.roundDot,
                    ...(i < roundsPlayed ? { background: i < roundsWon ? '#34d399' : '#f87171' } : {}),
                    ...(i === roundsPlayed ? { background: '#fbbf24' } : {}),
                  }}
                />
              ))}
            </div>
            
            <div style={styles.progress}>
              {Array.from({ length: TRIALS_PER_ROUND }).map((_, i) => (
                <div 
                  key={i} 
                  style={{
                    ...styles.progressBar,
                    ...(i < trialCount ? styles.progressBarFilled : {}),
                  }}
                />
              ))}
            </div>
            
            <div style={{
              ...styles.ruleBadge,
              borderColor: currentRule === 'color' ? '#a78bfa' : '#34d399',
              color: currentRule === 'color' ? '#a78bfa' : '#34d399',
            }}>
              Sort by {currentRule.toUpperCase()}
            </div>
            
            {currentStimulus && (
              <>
                <div style={styles.stimulusContainer}>
                  <div style={{
                    ...styles.stimulus,
                    background: colorMap[currentStimulus.color].bg,
                    borderRadius: currentStimulus.shape === 'circle' ? '50%' : '16px',
                    boxShadow: `0 0 30px ${colorMap[currentStimulus.color].shadow}`,
                    transform: feedback?.correct === false ? 'scale(0.95)' : 'scale(1)',
                  }} />
                </div>
                
                <div style={styles.responseButtons}>
                  {currentRule === 'color' ? (
                    <>
                      <button
                        style={{
                          ...styles.responseButton,
                          background: colorMap.violet.bg,
                          boxShadow: `0 4px 20px ${colorMap.violet.shadow}`,
                        }}
                        onClick={() => handleResponse('violet')}
                      >
                        Violet
                      </button>
                      <button
                        style={{
                          ...styles.responseButton,
                          background: colorMap.amber.bg,
                          boxShadow: `0 4px 20px ${colorMap.amber.shadow}`,
                          color: '#000',
                        }}
                        onClick={() => handleResponse('amber')}
                      >
                        Amber
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        style={{
                          ...styles.responseButton,
                          background: 'rgba(52, 211, 153, 0.2)',
                          border: '2px solid #34d399',
                        }}
                        onClick={() => handleResponse('circle')}
                      >
                        ● Circle
                      </button>
                      <button
                        style={{
                          ...styles.responseButton,
                          background: 'rgba(52, 211, 153, 0.2)',
                          border: '2px solid #34d399',
                        }}
                        onClick={() => handleResponse('square')}
                      >
                        ■ Square
                      </button>
                    </>
                  )}
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
