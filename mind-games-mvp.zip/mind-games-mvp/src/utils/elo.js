/**
 * Elo Rating System for Cognitive Training
 * 
 * The Elo system adapts game difficulty based on user performance.
 * Higher ratings = harder challenges. Winning against harder challenges = bigger gains.
 */

export const INITIAL_ELO = 1000;
export const K_FACTOR = 32;

/**
 * Calculate expected score based on Elo ratings
 * @param {number} playerRating - User's current Elo rating
 * @param {number} challengeRating - Difficulty rating of the challenge
 * @returns {number} Expected probability of success (0-1)
 */
export const calculateExpectedScore = (playerRating, challengeRating) => {
  return 1 / (1 + Math.pow(10, (challengeRating - playerRating) / 400));
};

/**
 * Update Elo rating after a round
 * @param {number} rating - Current rating
 * @param {number} expected - Expected score (from calculateExpectedScore)
 * @param {number} actual - Actual result (1 for win, 0 for loss)
 * @returns {number} New rating
 */
export const updateElo = (rating, expected, actual) => {
  return Math.round(rating + K_FACTOR * (actual - expected));
};

/**
 * Get difficulty rating based on level
 * @param {number} level - Current game level
 * @returns {number} Difficulty Elo rating
 */
export const getDifficultyRating = (level) => 800 + (level * 100);

/**
 * Convert Elo to a user-friendly Cognitive Score (0-100+)
 * @param {number} elo - User's Elo rating
 * @returns {number} Cognitive score
 */
export const elotoCognitiveScore = (elo) => {
  return Math.max(0, Math.round((elo - 600) / 4));
};

/**
 * Get starting level based on current Elo
 * @param {number} elo - User's Elo rating
 * @returns {number} Recommended starting level
 */
export const getStartingLevel = (elo) => {
  return Math.max(1, Math.floor((elo - 800) / 100));
};

/**
 * Get performance tier label
 * @param {number} score - Cognitive score
 * @returns {string} Tier label
 */
export const getPerformanceTier = (score) => {
  if (score >= 120) return 'Elite';
  if (score >= 100) return 'Expert';
  if (score >= 80) return 'Advanced';
  if (score >= 60) return 'Proficient';
  if (score >= 40) return 'Developing';
  return 'Beginner';
};
