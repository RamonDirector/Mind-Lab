/**
 * Local Storage Utilities for Mind Games
 * Handles persisting user progress, ratings, and streak data
 */

const STORAGE_KEY = 'mindgames_data';

const defaultData = {
  ratings: {
    pattern: 1000,
    switcher: 1000,
    clarity: 1000,
  },
  streak: {
    current: 0,
    freezesAvailable: 1,
    lastPlayedDate: null,
  },
  history: [],
  settings: {
    soundEnabled: true,
    hapticEnabled: true,
  },
};

/**
 * Get all stored data
 * @returns {Object} User data
 */
export const getData = () => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return { ...defaultData, ...JSON.parse(stored) };
    }
  } catch (e) {
    console.warn('Failed to load data from localStorage:', e);
  }
  return defaultData;
};

/**
 * Save data to storage
 * @param {Object} data - Data to save
 */
export const saveData = (data) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn('Failed to save data to localStorage:', e);
  }
};

/**
 * Update a specific game's rating
 * @param {string} gameId - Game identifier
 * @param {number} newRating - New Elo rating
 */
export const updateRating = (gameId, newRating) => {
  const data = getData();
  data.ratings[gameId] = newRating;
  saveData(data);
  return data;
};

/**
 * Get combined cognitive score across all games
 * @returns {number} Average cognitive score
 */
export const getCombinedScore = () => {
  const data = getData();
  const ratings = Object.values(data.ratings);
  const avgRating = ratings.reduce((a, b) => a + b, 0) / ratings.length;
  return Math.max(0, Math.round((avgRating - 600) / 4));
};

/**
 * Update streak data
 * @param {boolean} completed - Whether today's workout was completed
 */
export const updateStreak = (completed) => {
  const data = getData();
  const today = new Date().toDateString();
  const lastPlayed = data.streak.lastPlayedDate;
  
  if (completed) {
    if (lastPlayed === today) {
      // Already played today
      return data;
    }
    
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (lastPlayed === yesterday.toDateString()) {
      // Consecutive day - extend streak
      data.streak.current += 1;
    } else if (lastPlayed !== today) {
      // Streak broken - check for freeze
      if (data.streak.freezesAvailable > 0) {
        data.streak.freezesAvailable -= 1;
      } else {
        data.streak.current = 1;
      }
    }
    
    data.streak.lastPlayedDate = today;
  }
  
  saveData(data);
  return data;
};

/**
 * Add a game session to history
 * @param {Object} session - Session data
 */
export const addToHistory = (session) => {
  const data = getData();
  data.history.unshift({
    ...session,
    timestamp: new Date().toISOString(),
  });
  // Keep last 100 sessions
  data.history = data.history.slice(0, 100);
  saveData(data);
  return data;
};

/**
 * Reset all data (for development/testing)
 */
export const resetData = () => {
  saveData(defaultData);
  return defaultData;
};
